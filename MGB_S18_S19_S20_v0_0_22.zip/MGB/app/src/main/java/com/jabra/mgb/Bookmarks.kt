package com.jabra.mgb

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/**
 * S13: bookmarks (also the speed dial tiles) and browsing history, stored as JSON in filesDir.
 *  - mgb_bookmarks.json: seeded with a few sites on the first run, then fully user controlled
 *  - mgb_history.json: newest first, max MAX_HISTORY entries, same url twice in a row = one entry
 * All calls are cheap and safe from the main thread; the disk write runs on one background thread.
 */
object Bookmarks {
    class Item(val title: String, val url: String, val time: Long)

    private const val MAX_HISTORY = 500
    private const val F_BM = "mgb_bookmarks.json"
    private const val F_HIST = "mgb_history.json"

    private var dir: File? = null
    private val bm = ArrayList<Item>()
    private val hist = ArrayList<Item>()
    private val io = Executors.newSingleThreadExecutor()

    @Synchronized
    fun init(ctx: Context) {
        if (dir != null) return
        val d = ctx.applicationContext.filesDir
        dir = d
        val fb = File(d, F_BM)
        if (fb.exists()) read(fb, bm) else {
            val now = System.currentTimeMillis()
            bm.add(Item("Google", "https://www.google.com", now))
            bm.add(Item("YouTube", "https://www.youtube.com", now))
            bm.add(Item("Wikipedia", "https://www.wikipedia.org", now))
            bm.add(Item("GitHub", "https://github.com", now))
            saveAsync(F_BM, bm)
        }
        read(File(d, F_HIST), hist)
    }

    private fun read(f: File, out: ArrayList<Item>) {
        try {
            if (!f.exists()) return
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val u = o.optString("u")
                if (u.isNotEmpty()) out.add(Item(o.optString("t"), u, o.optLong("w")))
            }
        } catch (e: Exception) { /* broken file: start empty */ }
    }

    private fun saveAsync(name: String, list: List<Item>) {
        val d = dir ?: return
        val arr = JSONArray()
        for (x in list) arr.put(JSONObject().put("t", x.title).put("u", x.url).put("w", x.time))
        val text = arr.toString()
        io.execute {
            try {
                val tmp = File(d, "$name.tmp")
                tmp.writeText(text)
                if (!tmp.renameTo(File(d, name))) { File(d, name).writeText(text); tmp.delete() }
            } catch (e: Exception) { /* storage full etc: keep running */ }
        }
    }

    // ---------- bookmarks ----------

    @Synchronized fun bookmarks(): List<Item> = bm.toList()

    @Synchronized fun isBookmarked(url: String): Boolean = bm.any { it.url == url }

    @Synchronized
    fun addBookmark(title: String, url: String) {
        if (url.isBlank() || bm.any { it.url == url }) return
        bm.add(Item(title.ifBlank { Util.host(url) }, url, System.currentTimeMillis()))
        saveAsync(F_BM, bm)
    }

    @Synchronized
    fun removeBookmark(url: String) {
        if (bm.removeAll { it.url == url }) saveAsync(F_BM, bm)
    }

    // ---------- S18: import / export ----------

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun unesc(s: String) = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
        .replace("&#39;", "'").replace("&#x27;", "'").replace("&amp;", "&")

    private val A_TAG = Regex("<a\\s[^>]*?href\\s*=\\s*([\"'])(.*?)\\1[^>]*>(.*?)</a>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val ANY_TAG = Regex("<[^>]*>")

    /** Standard browser bookmark file (Netscape HTML): opens in Chrome, Firefox, Edge ... */
    @Synchronized
    fun exportHtml(): String {
        val sb = StringBuilder()
        sb.append("<!DOCTYPE NETSCAPE-Bookmark-file-1>\n")
        sb.append("<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=UTF-8\">\n")
        sb.append("<TITLE>Bookmarks</TITLE>\n<H1>Bookmarks</H1>\n<DL><p>\n")
        for (x in bm) {
            sb.append("    <DT><A HREF=\"").append(esc(x.url)).append("\" ADD_DATE=\"").append(x.time / 1000).append("\">")
                .append(esc(x.title.ifBlank { x.url })).append("</A>\n")
        }
        sb.append("</DL><p>\n")
        return sb.toString()
    }

    /**
     * Reads a browser bookmark HTML file, or a JSON list (own mgb_bookmarks.json style: t/u or title/url).
     * Only http(s) links, duplicates skipped, max 2000 bookmarks. Returns how many were added.
     */
    @Synchronized
    fun importText(text: String): Int {
        val found = ArrayList<Pair<String, String>>()
        val t = text.trimStart('\uFEFF', ' ', '\n', '\r', '\t')
        if (t.startsWith("[") || t.startsWith("{")) {
            val arr = try { if (t.startsWith("[")) JSONArray(t) else JSONObject(t).optJSONArray("bookmarks") } catch (e: Exception) { null }
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val u = o.optString("u", o.optString("url"))
                    if (u.isNotEmpty()) found.add(Pair(o.optString("t", o.optString("title")), u))
                }
            }
        } else {
            for (m in A_TAG.findAll(text)) {
                found.add(Pair(unesc(m.groupValues[3].replace(ANY_TAG, "").trim()), unesc(m.groupValues[2].trim())))
            }
        }
        var n = 0
        val now = System.currentTimeMillis()
        for ((title, u) in found) {
            if (bm.size >= 2000) break
            if (!(u.startsWith("http://") || u.startsWith("https://"))) continue
            if (bm.any { it.url == u }) continue
            bm.add(Item(title.ifBlank { Util.host(u) }, u, now))
            n++
        }
        if (n > 0) saveAsync(F_BM, bm)
        return n
    }

    // ---------- history ----------

    @Synchronized fun history(): List<Item> = hist.toList()

    @Synchronized
    fun addHistory(title: String, url: String) {
        if (url.isBlank()) return
        val now = System.currentTimeMillis()
        val top = hist.firstOrNull()
        if (top != null && top.url == url) hist.removeAt(0)
        hist.add(0, Item(title.ifBlank { Util.host(url) }, url, now))
        while (hist.size > MAX_HISTORY) hist.removeAt(hist.size - 1)
        saveAsync(F_HIST, hist)
    }

    @Synchronized
    fun removeHistory(time: Long, url: String) {
        if (hist.removeAll { it.time == time && it.url == url }) saveAsync(F_HIST, hist)
    }

    @Synchronized
    fun clearHistory() {
        hist.clear()
        saveAsync(F_HIST, hist)
    }
}
